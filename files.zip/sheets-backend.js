/**
 * IRONSERVICE KK — Google Apps Script Backend
 * ============================================
 * วิธีติดตั้ง:
 * 1. เปิด Google Sheets ใหม่ ตั้งชื่อว่า "IRONSERVICE KK Database"
 * 2. ไปที่ Extensions → Apps Script
 * 3. วางโค้ดทั้งหมดนี้แทนที่โค้ดเดิม
 * 4. บันทึก (Ctrl+S)
 * 5. Deploy → New Deployment → Web App
 *    - Execute as: Me
 *    - Who has access: Anyone
 * 6. คัดลอก URL ที่ได้ → ใส่ใน Admin Settings หรือ payment.html
 * ============================================
 */

// ============================================
// SHEET NAMES
// ============================================
const SHEETS = {
  ORDERS: 'Orders',
  PAYMENTS: 'Payments',
  CUSTOMERS: 'Customers',
  LOGS: 'Logs',
  SETTINGS: 'Settings'
};

// ============================================
// MAIN ENTRY POINT (POST)
// ============================================
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const action = data.action || data.sheet;
    
    let result;
    
    switch (action) {
      case 'payments':
      case 'add_payment':
        result = addPayment(data);
        sendLineNotify(`💳 การชำระเงินใหม่!\nออเดอร์: ${data.orderId}\nลูกค้า: ${data.customer}\nยอด: ฿${data.amount?.toLocaleString()}\nวิธี: ${data.method}\nRef: ${data.ref}`);
        break;
      
      case 'add_order':
        result = addOrder(data);
        break;
      
      case 'update_order':
        result = updateOrder(data);
        if (data.notify === 'yes') {
          const msg = getStatusMessage(data.status, data.orderId, data.customer, data.progress);
          sendLineNotify(msg);
        }
        break;
      
      case 'add_customer':
        result = addCustomer(data);
        break;
      
      case 'get_order':
        result = getOrder(data.orderId);
        break;
      
      case 'get_orders':
        result = getAllOrders();
        break;
        
      case 'get_payments':
        result = getAllPayments();
        break;
      
      case 'verify_payment':
        result = updatePaymentStatus(data.ref, 'verified');
        break;
      
      case 'log':
        result = addLog(data.message, data.type);
        break;
      
      default:
        result = { error: 'Unknown action: ' + action };
    }
    
    return ContentService
      .createTextOutput(JSON.stringify({ success: true, ...result }))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ success: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ============================================
// MAIN ENTRY POINT (GET)
// ============================================
function doGet(e) {
  const action = e.parameter.action;
  const orderId = e.parameter.orderId;
  
  try {
    let result;
    
    if (action === 'get_order' && orderId) {
      result = getOrder(orderId);
    } else if (action === 'get_orders') {
      result = getAllOrders();
    } else if (action === 'get_payments') {
      result = getAllPayments();
    } else if (action === 'stats') {
      result = getStats();
    } else {
      result = { message: 'IRONSERVICE KK API v1.0', status: 'running' };
    }
    
    return ContentService
      .createTextOutput(JSON.stringify({ success: true, ...result }))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ success: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ============================================
// SETUP SHEETS (Run once to initialize)
// ============================================
function setupSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // ORDERS sheet
  let ordersSheet = ss.getSheetByName(SHEETS.ORDERS);
  if (!ordersSheet) {
    ordersSheet = ss.insertSheet(SHEETS.ORDERS);
    ordersSheet.getRange(1, 1, 1, 12).setValues([[
      'ออเดอร์ ID', 'ลูกค้า', 'เบอร์โทร', 'ประเภทงาน', 'รายละเอียด',
      'ราคา', 'มัดจำ', 'สถานะ', 'ความคืบหน้า', 'การชำระ', 'วันที่', 'หมายเหตุ'
    ]]);
    ordersSheet.getRange(1, 1, 1, 12).setFontWeight('bold');
    ordersSheet.setFrozenRows(1);
  }
  
  // PAYMENTS sheet
  let paymentsSheet = ss.getSheetByName(SHEETS.PAYMENTS);
  if (!paymentsSheet) {
    paymentsSheet = ss.insertSheet(SHEETS.PAYMENTS);
    paymentsSheet.getRange(1, 1, 1, 10).setValues([[
      'รหัสการชำระ', 'ออเดอร์ ID', 'ลูกค้า', 'วิธีชำระ', 'ยอดเงิน',
      'มีสลิป', 'วันที่', 'เวลา', 'สถานะ', 'หมายเหตุ'
    ]]);
    paymentsSheet.getRange(1, 1, 1, 10).setFontWeight('bold');
    paymentsSheet.setFrozenRows(1);
  }
  
  // CUSTOMERS sheet
  let customersSheet = ss.getSheetByName(SHEETS.CUSTOMERS);
  if (!customersSheet) {
    customersSheet = ss.insertSheet(SHEETS.CUSTOMERS);
    customersSheet.getRange(1, 1, 1, 7).setValues([[
      'ชื่อ', 'เบอร์โทร', 'อีเมล', 'LINE ID', 'จำนวนออเดอร์', 'ยอดรวม', 'วันที่สมัคร'
    ]]);
    customersSheet.getRange(1, 1, 1, 7).setFontWeight('bold');
    customersSheet.setFrozenRows(1);
  }
  
  // LOGS sheet
  let logsSheet = ss.getSheetByName(SHEETS.LOGS);
  if (!logsSheet) {
    logsSheet = ss.insertSheet(SHEETS.LOGS);
    logsSheet.getRange(1, 1, 1, 4).setValues([['วันที่', 'เวลา', 'ประเภท', 'ข้อความ']]);
    logsSheet.getRange(1, 1, 1, 4).setFontWeight('bold');
    logsSheet.setFrozenRows(1);
  }
  
  // SETTINGS sheet
  let settingsSheet = ss.getSheetByName(SHEETS.SETTINGS);
  if (!settingsSheet) {
    settingsSheet = ss.insertSheet(SHEETS.SETTINGS);
    settingsSheet.getRange(1, 1, 8, 2).setValues([
      ['LINE_NOTIFY_TOKEN', ''],
      ['PROMPTPAY_NUMBER', '0637409696'],
      ['SHOP_NAME', 'IRONSERVICE KK'],
      ['SHOP_PHONE', '063-740-9696'],
      ['SHOP_LINE', '@ironservicekk'],
      ['DEPOSIT_PERCENT', '50'],
      ['AUTO_NOTIFY', 'true'],
      ['LAST_UPDATED', new Date().toISOString()]
    ]);
  }
  
  SpreadsheetApp.getUi().alert('✅ ติดตั้งฐานข้อมูลสำเร็จ! ระบบพร้อมใช้งาน');
}

// ============================================
// ORDERS CRUD
// ============================================
function addOrder(data) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEETS.ORDERS);
  
  const now = new Date();
  const deposit = Math.ceil((data.price || 0) * 0.5 / 100) * 100;
  
  sheet.appendRow([
    data.id || `QU-${Date.now().toString().slice(-5)}`,
    data.customer || '',
    data.phone || '',
    data.type || 'general',
    data.detail || '',
    data.price || 0,
    deposit,
    data.status || 'pending',
    data.progress || 5,
    data.payStatus || 'unpaid',
    now.toLocaleDateString('th-TH'),
    data.note || ''
  ]);
  
  addLog(`สร้างออเดอร์ใหม่: ${data.id} — ${data.customer}`, 'ORDER');
  return { id: data.id, message: 'Order created' };
}

function getOrder(orderId) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEETS.ORDERS);
  const data = sheet.getDataRange().getValues();
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === orderId) {
      return {
        order: {
          id: data[i][0],
          customer: data[i][1],
          phone: data[i][2],
          type: data[i][3],
          detail: data[i][4],
          price: data[i][5],
          deposit: data[i][6],
          status: data[i][7],
          progress: data[i][8],
          payStatus: data[i][9],
          date: data[i][10],
          note: data[i][11]
        }
      };
    }
  }
  return { order: null, error: 'Order not found' };
}

function getAllOrders() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEETS.ORDERS);
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  
  const orders = data.slice(1).map(row => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return obj;
  });
  
  return { orders, total: orders.length };
}

function updateOrder(data) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEETS.ORDERS);
  const rows = sheet.getDataRange().getValues();
  
  for (let i = 1; i < rows.length; i++) {
    if (rows[i][0] === data.orderId) {
      if (data.status) sheet.getRange(i + 1, 8).setValue(data.status);
      if (data.progress !== undefined) sheet.getRange(i + 1, 9).setValue(data.progress);
      if (data.payStatus) sheet.getRange(i + 1, 10).setValue(data.payStatus);
      addLog(`อัพเดทออเดอร์ ${data.orderId}: สถานะ=${data.status}, คืบหน้า=${data.progress}%`, 'UPDATE');
      return { updated: true };
    }
  }
  return { updated: false, error: 'Order not found' };
}

// ============================================
// PAYMENTS
// ============================================
function addPayment(data) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEETS.PAYMENTS);
  const now = new Date();
  
  sheet.appendRow([
    data.ref || `PAY-${Date.now().toString().slice(-6)}`,
    data.orderId || '',
    data.customer || '',
    data.method || 'PromptPay',
    data.amount || 0,
    data.hasSlip ? 'ใช่' : 'ไม่มี',
    now.toLocaleDateString('th-TH'),
    now.toLocaleTimeString('th-TH'),
    'pending',
    data.note || ''
  ]);
  
  addLog(`การชำระเงินใหม่: ${data.ref} ออเดอร์ ${data.orderId} ฿${data.amount}`, 'PAYMENT');
  return { ref: data.ref, message: 'Payment recorded' };
}

function getAllPayments() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEETS.PAYMENTS);
  const data = sheet.getDataRange().getValues();
  const payments = data.slice(1).map(row => ({
    ref: row[0], orderId: row[1], customer: row[2],
    method: row[3], amount: row[4], hasSlip: row[5],
    date: row[6], time: row[7], status: row[8], note: row[9]
  }));
  return { payments, pending: payments.filter(p => p.status === 'pending').length };
}

function updatePaymentStatus(ref, status) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEETS.PAYMENTS);
  const rows = sheet.getDataRange().getValues();
  
  for (let i = 1; i < rows.length; i++) {
    if (rows[i][0] === ref) {
      sheet.getRange(i + 1, 9).setValue(status);
      addLog(`อัพเดทการชำระ ${ref}: ${status}`, 'PAYMENT');
      return { updated: true };
    }
  }
  return { updated: false };
}

// ============================================
// CUSTOMERS
// ============================================
function addCustomer(data) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEETS.CUSTOMERS);
  const now = new Date();
  
  // Check if exists
  const rows = sheet.getDataRange().getValues();
  for (let i = 1; i < rows.length; i++) {
    if (rows[i][1] === data.phone) {
      // Update order count
      sheet.getRange(i + 1, 5).setValue((rows[i][4] || 0) + 1);
      return { existing: true };
    }
  }
  
  sheet.appendRow([
    data.customer || '',
    data.phone || '',
    data.email || '',
    data.lineId || '',
    1,
    data.price || 0,
    now.toLocaleDateString('th-TH')
  ]);
  return { created: true };
}

// ============================================
// STATS
// ============================================
function getStats() {
  const ordersResult = getAllOrders();
  const paymentsResult = getAllPayments();
  const orders = ordersResult.orders || [];
  const payments = paymentsResult.payments || [];
  
  const revenue = payments
    .filter(p => p.status === 'verified')
    .reduce((sum, p) => sum + (parseFloat(p.amount) || 0), 0);
  
  return {
    totalOrders: orders.length,
    pendingOrders: orders.filter(o => o['สถานะ'] === 'pending').length,
    inProduction: orders.filter(o => o['สถานะ'] === 'production').length,
    pendingPayments: payments.filter(p => p.status === 'pending').length,
    verifiedRevenue: revenue
  };
}

// ============================================
// LOGS
// ============================================
function addLog(message, type = 'INFO') {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEETS.LOGS);
    const now = new Date();
    sheet.appendRow([
      now.toLocaleDateString('th-TH'),
      now.toLocaleTimeString('th-TH'),
      type,
      message
    ]);
  } catch (e) {
    // Silently fail
  }
}

// ============================================
// LINE NOTIFY
// ============================================
function sendLineNotify(message) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const settingsSheet = ss.getSheetByName(SHEETS.SETTINGS);
    const settings = settingsSheet.getDataRange().getValues();
    
    let token = '';
    settings.forEach(row => {
      if (row[0] === 'LINE_NOTIFY_TOKEN') token = row[1];
    });
    
    if (!token) return;
    
    UrlFetchApp.fetch('https://notify-api.line.me/api/notify', {
      method: 'post',
      headers: { 'Authorization': 'Bearer ' + token },
      payload: { message: '\n' + message }
    });
  } catch (e) {
    addLog('LINE Notify Error: ' + e.toString(), 'ERROR');
  }
}

function getStatusMessage(status, orderId, customer, progress) {
  const statusTH = {
    pending: 'รอดำเนินการ',
    design: 'กำลังออกแบบ 3D',
    production: 'กำลังผลิต',
    qc: 'ตรวจสอบคุณภาพ',
    shipping: 'จัดส่งแล้ว',
    done: 'เสร็จสมบูรณ์'
  };
  return `📦 อัพเดทออเดอร์ IRONSERVICE KK\n` +
    `ออเดอร์: ${orderId}\n` +
    `ลูกค้า: ${customer}\n` +
    `สถานะ: ${statusTH[status] || status}\n` +
    `ความคืบหน้า: ${progress}%\n` +
    `ติดตาม: https://ironservicekk.com#tracking`;
}

// ============================================
// MENU (for spreadsheet UI)
// ============================================
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('🔧 IRONSERVICE KK')
    .addItem('⚙️ ติดตั้งระบบ (ครั้งแรก)', 'setupSheets')
    .addItem('📊 ดูสถิติ', 'showStats')
    .addItem('🔄 ส่ง LINE Notify ทดสอบ', 'testLineNotify')
    .addSeparator()
    .addItem('📋 Export CSV', 'exportCSV')
    .addToUi();
}

function showStats() {
  const stats = getStats();
  SpreadsheetApp.getUi().alert(
    `📊 สถิติ IRONSERVICE KK\n\n` +
    `ออเดอร์ทั้งหมด: ${stats.totalOrders}\n` +
    `รอดำเนินการ: ${stats.pendingOrders}\n` +
    `กำลังผลิต: ${stats.inProduction}\n` +
    `รอตรวจสอบชำระ: ${stats.pendingPayments}\n` +
    `รายได้ยืนยัน: ฿${stats.verifiedRevenue.toLocaleString()}`
  );
}

function testLineNotify() {
  sendLineNotify('🔔 ทดสอบระบบแจ้งเตือน IRONSERVICE KK — ระบบพร้อมใช้งาน!');
  SpreadsheetApp.getUi().alert('ส่ง LINE Notify สำเร็จ!');
}

function exportCSV() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ordersSheet = ss.getSheetByName(SHEETS.ORDERS);
  const data = ordersSheet.getDataRange().getValues();
  let csv = data.map(row => row.join(',')).join('\n');
  SpreadsheetApp.getUi().alert('CSV Export: ไปที่ File → Download → CSV');
}
